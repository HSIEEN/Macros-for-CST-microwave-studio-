function [hasConverged,OptimizedValue] = Interpolation(PrjFile,...
    Variable,VRange,GoalValue,Accuracy)
addpath('C:\Program Files\MATLAB\R2014a\bin\CST-MATLAB-API-master');
%Optimization the Vararibale within range of VRange
%The goalValue is resonance frequency
%Parameters
%@Variable: variable to be optimized
%@VRange: variable range to be optimized in
%@GoalVar: objective variable
%@GoalValue: value of objective variable
%Set  frequency
fC = GoalValue;
% Optimization stop conditions.
maxIters     = 10;        % max # of iterations.
hasConverged = false;     % converge status
% set maximum and minimum value of variable to be optimized

Min = VRange(1,1);
Max = VRange(1,2);
cst = actxserver('CSTStudio.application');

%This command is used to open a new CST project. From now on this mws
%variable will be used to operate any matlab function that is used for the
%control of CST
mws = invoke(cst,'OpenFile',PrjFile);
fprintf('Running when the varaible is at maximum......\n ');
try
    [fmax,~] = CST(mws,Variable,Max );
catch
    [fmax,~] = CST(mws,Variable,Max );
end
fprintf('The resonance frequency at maximum value is: %.4f GHz\n',...
    fmax);
%fprintf('Running when the varaible is at minimum......\n ');
%[fmin,~] = HFSS(ScriptFile,hfssExePath,PrjFile,DesignName,SetupName,...
%    Variable,Min,ModName,Material,PlotName,CsvFile );
try
    [fmin,~] = CST(mws,Variable,Min );
catch
    [fmin,~] = CST(mws,Variable,Min );
end

fprintf('The resonance frequency at minimum value is: %.4f GHz\n',...
    fmin);

for iIters = 1:maxIters
   
    fprintf('Running iteration #%d.........\n', iIters);
    %interpolation search algorithm
    Mid = Min+(fC-fmin)/(fmax-fmin)*(Max-Min);
    fprintf(['The new estimated value of ',Variable,' is %.3f mm\n'],...
        Mid);
    try
        [fmid,~] = CST(mws,Variable,Mid );
    catch
        continue;
    end
    
    fprintf('Simulated Resonance Frequency: %.4f GHz\n', fmid);
    
    % Check if the required accuracy is met.
    if (abs((fC - fmid)/fC) < Accuracy)
        disp('Required Accuracy is met!');
        fprintf('Optimized Variable is %.3f mm.\n', Mid);
        hasConverged = true;
        
        OptimizedValue  = Mid;
        break;
    else
        %interpolation search algorithm
        
        if fmid < fC
            Min = Mid;
            fmin = fmid;
        else
            Max = Mid;
            fmax = fmid;
        end
    end
    disp('Required accuracy not yet met ...');
end
%DataFile = [Direct, '\tmpData', num2str(iIters), '.m'];
% The data items are in the f, S, Z variables now.
% Plot the data.
%disp('Solution Completed. Plotting Results for this iteration...');
%figure(1);
%hold on; grid on;
% plot(f/1e9, LogS, pltCols(mod(iIters, nCols) + 1));
%hold on;
%xlabel('Frequency (GHz)');
%ylabel('S_{12} (dB)');
%axis([fLow/1e9, fHigh/1e9, -50, 0]);
if (~hasConverged)
    disp('Max Iterations exceeded. Optimization did NOT converge .....');
    OptimizedValue = Mid;
    %fprintf('...The current  #%d...\n', iIters);
    
end
CstQuitProject(mws);
disp('');
disp('');

end
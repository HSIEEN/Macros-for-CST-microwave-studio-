% Copyright (C) 2018  Symeon Symeonidis, Stefanos Tsantilas, Stelios Mitilineos
% simos421@gmail.com, steftsantilas@gmail.com, smitil@gmail.com
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.



%This is a step by step tutorial on how to use the CST-Matlab-API
%The steps you'll see here can be applied in all of the examples that are
%found in the example folderyf
function [fActual,dBmag] = CST(mws,VarName,VarValue)
addpath('C:\Program Files\MATLAB\R2014a\bin\CST-MATLAB-API-master');

%This command is used to initiate the CST application, as you can see here, it is assigned to
%the cst variable.


%Sets default units for your project. mm, GHz e.t.c you can open
%CSTDefaultUnits to see the exact selections or if you want I have


invoke(mws,'StoreParameter',VarName,VarValue);
invoke(mws,'Rebuild');
%Defines the solver and starts simulation (I also have frequency domain solver and Integral solver)
%-40 corresponds to accuracy
CstDefineTimedomainSolver(mws,-40)

%Here you need to define the path that you want your s parametters to be
%exported and the name of your file. Mine for instance are:
% exportpath = 'C:\Users\simos\Dropbox\cst api\microstrip';
% filenameTXT = 'microstrip';
exportpath = 'C:\SimDirect\CST\MATLAB\FPA.txt';
filenameTXT = exportpath;

%Here the S11 is exported as a .txt file and plotted
CstExportSparametersTXT(mws, exportpath)
[Frequency, Sparametter] = CstLoadSparametterTXT(filenameTXT);

[~,minIndex] = min(Sparametter);
fActual = Frequency(minIndex);
dBmag = Sparametter(minIndex);

%In the API's folders you'll find many more functions that do all kinds of stuff in CST.
%As you've seen in this tutorial the name of each function prety much describes what it does
%Always remember first to call the function of your desired material before you assing it into a
%geometry
%Feel free to experiment with them! Have fun!

end


